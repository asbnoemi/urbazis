asboth noémi bkdh50
tk==0.1.0
csv
ez a program egy kébzeletbeli ürkikötöurhajo felszálási terveit kezeli
