import csv


class indulas:
    def __init__(self):
        self.ido=""
        self.alomas=""
        self.tip=""
        self.utassz=""
        
class Csvfile:
    def __init__(self):
        self.filename='felszalas.csv'
        self.fejlec=[]
        self.adatsor=[]
        
    def olvas(self):
        with open(self.filename, newline='') as csvfile:
            olvaso = csv.reader(csvfile, delimiter=';', quotechar='\'')
            for raw in olvaso:
                sor=indulas()
                sor.ido=raw[0]
                sor.alomas=raw[1]
                sor.tip=raw[2]
                sor.utassz=raw[3]
                self.adatsor.append(sor)
    
    def ir(self,indul:indulas):
         with open(self.filename, 'a', newline='') as csvfile:
            iro = csv.writer(csvfile, delimiter=';',quotechar='\'', quoting=csv.QUOTE_MINIMAL)
            iro.writerow([ indul.ido , indul.alomas, indul.tip,indul.utassz])       
                
        
