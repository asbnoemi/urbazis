
from tkinter import*
import anCsv.csv_kezel
from anCsv import*
    
class ui:
    def __init__(self):
        self.diag=None
               
    def foablak(self):   
        app=Tk()     
        app.title("felszalas")
        app.geometry("500x500")
        teher= Button(app,text='teherhajok',command=self.teherB,width=10,height=3)
        katonai= Button(app,text='cirkálok',command=self.katonaiB,width=10,height=3)
        utas= Button(app,text='utasszálitok',command=self.utasszB,width=10,height=3)
        hozaad= Button(app,text='hozaad',command=self.hozaadB,width=10,height=3)
        teher.grid(row=0,column=0)
        katonai.grid(row=1,column=0)
        utas.grid(row=2,column=0)  
        hozaad.grid(row=0,column=2) 
        app.mainloop()
        self.diag=app
        
    def teherB(self):
        sorok=anCsv.csv_kezel.Csvfile()
        sorok.olvas()
        a=""
        for x in sorok.adatsor:
            if x.utassz=='0':
                a+=x.ido + " " 
                a+="álomásrol: " + x.alomas + " "
                a+="tipusu: " +  x.tip + "\n " 
                
        adat=Label(text=a)
        adat.grid(row=0,column=1)     
        
    
    def katonaiB(self):
        sorok=anCsv.csv_kezel.Csvfile()
        sorok.olvas()
        a=""
        for x in sorok.adatsor:
            if x.tip=='DSF-31':
                a+=x.ido + " " 
                a+="álomásrol: " + x.alomas + " "
                a+="tipusu: " +  x.tip + "\n " 
                
        adat=Label(text=a)
        adat.grid(row=1,column=1)    

    def utasszB(self):
        sorok=anCsv.csv_kezel.Csvfile()
        sorok.olvas()
        a=""
        for x in sorok.adatsor:
            if x.utassz!='0' and x.tip!='DSF-31' and  x.utassz!='utas':
                a+=x.ido + " " 
                a+="álomásrol: " + x.alomas + " "
                a+="tipusu: " +  x.tip + "\n " 
                
        adat=Label(text=a)
        adat.grid(row=2,column=1)    

    def hozaadB(self):
        def okB():
            i=anCsv.csv_kezel.indulas()
            i.utassz=utassz.get()
            i.ido=ido.get()
            i.tip=tip.get()
            i.alomas=alomas.get()
            sorok=anCsv.csv_kezel.Csvfile()
            sorok.ir(i)
            app2.destroy()
            
            
        app2=Toplevel(self.diag)
        app2.title("hozaad")
        app2.geometry("200x200")
        ok= Button(app2,text='ok',command=okB,width=10,height=3) 
        ido=StringVar()
        ido.set("")
        ido=Entry(app2,textvariable="ido",width=5)
        alomas=StringVar()
        alomas.set("")
        alomas=Entry(app2,textvariable="alomas",width=1)
        tip=StringVar()
        tip.set("")
        tip=Entry(app2,textvariable="tipus",width=5)
        utassz=StringVar()
        utassz.set("")
        utassz=Entry(app2,textvariable="utassz",width=4)
        idosz=Label(app2,text=("ido:"))
        alomassz=Label(app2,text=("alomas szám:"))
        tipsz=Label(app2,text=("tipus:"))
        utasszl=Label(app2,text=("utasok szama:"))
        utasszl.grid(row=3,column=0)
        tipsz.grid(row=2,column=0)
        idosz.grid(row=0,column=0)
        alomassz.grid(row=1,column=0)
        ok.grid(row=4,column=0)
        ido.grid(row=0,column=1)
        alomas.grid(row=1,column=1)
        tip.grid(row=2,column=1)
        utassz.grid(row=3,column=1)
        #self.diag=app2 
       
            
        
